-- Task 1: Identifying Approval Trends
-- 1.Determine the number of drugs approved each year and provide insights into the yearly trends.
SELECT YEAR(ActionDate) AS ApprovalYear, COUNT(DISTINCT ApplNo) AS ApprovedDrugsCount
FROM RegActionDate
WHERE ActionType = 'AP'
GROUP BY ApprovalYear
ORDER BY ApprovalYear;

-- 2.Identify the top three years that got the highest and lowest approvals, in descending and ascending order, respectively.
-- Top three years with the highest number of approvals
SELECT YEAR(ActionDate) AS ApprovalYear, COUNT(DISTINCT ApplNo) AS ApprovedDrugsCount
FROM RegActionDate
WHERE ActionType = 'AP'
GROUP BY ApprovalYear
ORDER BY ApprovedDrugsCount DESC
LIMIT 3;

-- Bottom three years with the lowest number of approvals
SELECT YEAR(ActionDate) AS ApprovalYear, COUNT(DISTINCT ApplNo) AS ApprovedDrugsCount
FROM RegActionDate
WHERE ActionType = 'AP'
GROUP BY ApprovalYear
ORDER BY ApprovedDrugsCount ASC
LIMIT 3;

-- 3.Explore approval trends over the years based on sponsors.
SELECT YEAR(y.ActionDate) AS ApprovalYear, x.SponsorApplicant,
COUNT(DISTINCT y.ApplNo) AS ApprovedDrugsCount
FROM RegActionDate AS y
JOIN Application AS x ON y.ApplNo = x.ApplNo
WHERE y.ActionType = 'AP'
GROUP BY ApprovalYear, x.SponsorApplicant
ORDER BY ApprovalYear, ApprovedDrugsCount DESC;

-- 4.Rank sponsors based on the total number of approvals they received each year between 1939 and 1960.
SELECT 
    SponsorApplicant, 
    SUM(TotalApprovals) AS TotalApprovals,
    DENSE_RANK() OVER (ORDER BY SUM(TotalApprovals) DESC) AS SponsorRank
FROM (
    SELECT 
        x.SponsorApplicant, 
        COUNT(DISTINCT y.ApplNo) AS TotalApprovals
    FROM 
        RegActionDate AS y
    JOIN 
        Application AS x ON y.ApplNo = x.ApplNo
    WHERE 
        y.ActionType = 'AP'
        AND YEAR(y.ActionDate) BETWEEN 1939 AND 1960
    GROUP BY 
        x.SponsorApplicant
) AS ApprovalCounts
GROUP BY 
    SponsorApplicant
ORDER BY 
    TotalApprovals DESC;

-- Task 2: Segmentation Analysis Based on Drug MarketingStatus
-- 1.Group products based on MarketingStatus. Provide meaningful insights into the segmentation patterns.
SELECT 
    ProductMktStatus,
    COUNT(*) AS ProductCount,
    ROUND((COUNT(*) / (SELECT COUNT(*) FROM Product)) * 100, 2) AS Percentage
FROM 
    Product
GROUP BY 
    ProductMktStatus
ORDER BY 
    ProductCount DESC;

-- 2.Calculate the total number of applications for each MarketingStatus year-wise after the year 2010.
SELECT 
    YEAR(y.ActionDate) AS ApplicationYear,
    x.ProductMktStatus,
    COUNT(DISTINCT x.ApplNo) AS TotalApplications
FROM 
    Product AS x
JOIN 
    RegActionDate AS y ON x.ApplNo = y.ApplNo
WHERE 
    YEAR(y.ActionDate) > 2010
GROUP BY 
    ApplicationYear, x.ProductMktStatus
ORDER BY 
    ApplicationYear, TotalApplications DESC;

-- 3.Identify the top MarketingStatus with the maximum number of applications and analyze its trend over time.
SELECT 
    ProductMktStatus,
    COUNT(DISTINCT ApplNo) AS TotalApplications
FROM 
    Product
GROUP BY 
    ProductMktStatus
ORDER BY 
    TotalApplications DESC
LIMIT 1;
-- we can see that the top marketting status with maximum number of applications is '3'
SELECT 
    YEAR(y.ActionDate) AS ApplicationYear,
    x.ProductMktStatus,
    COUNT(DISTINCT x.ApplNo) AS TotalApplications
FROM 
    Product AS x
JOIN 
    RegActionDate AS y ON x.ApplNo = y.ApplNo
WHERE 
    x.ProductMktStatus = '3'
GROUP BY 
    ApplicationYear
ORDER BY 
    ApplicationYear;
-- OR
SELECT 
    ApplicationYear,
    TotalApplications
FROM (
    SELECT 
        YEAR(y.ActionDate) AS ApplicationYear,
        COUNT(DISTINCT x.ApplNo) AS TotalApplications
    FROM 
        Product AS x
    JOIN 
        RegActionDate AS y ON x.ApplNo = y.ApplNo
    WHERE 
        x.ProductMktStatus = (
            SELECT 
                ProductMktStatus
            FROM 
                Product
            GROUP BY 
                ProductMktStatus
            ORDER BY 
                COUNT(DISTINCT ApplNo) DESC
            LIMIT 1
        ) 
    GROUP BY 
        ApplicationYear
) AS TopMarketingStatusTrend
ORDER BY 
    ApplicationYear;

-- Task 3: Analyzing Products
-- 1.Categorize Products by dosage form and analyze their distribution.
SELECT 
    Form AS DosageForm,
    COUNT(*) AS ProductCount,
    ROUND((COUNT(*) / (SELECT COUNT(*) FROM Product)) * 100, 2) AS Percentage
FROM 
    Product
GROUP BY 
    DosageForm
ORDER BY 
    ProductCount DESC;

-- 2.Calculate the total number of approvals for each dosage form and identify the most successful forms.
	SELECT 
		x.Form AS DosageForm,
		COUNT(DISTINCT y.ApplNo) AS TotalApprovals
	FROM 
		Product AS x
	JOIN 
		RegActionDate AS y ON x.ApplNo = y.ApplNo
	WHERE 
		y.ActionType = 'AP'
	GROUP BY 
		DosageForm
	ORDER BY 
		TotalApprovals DESC;

-- 3.Investigate yearly trends related to successful forms.
SELECT 
    x.Form AS SuccessfulDosageForm,
    COUNT(DISTINCT y.ApplNo) AS TotalApprovals
FROM 
    Product AS x
JOIN 
    RegActionDate AS y ON x.ApplNo = y.ApplNo
WHERE 
    y.ActionType = 'AP'
GROUP BY 
    SuccessfulDosageForm
ORDER BY 
    TotalApprovals DESC
LIMIT 5;

 SELECT 
    YEAR(y.ActionDate) AS ApprovalYear,
    x.Form AS SuccessfulDosageForm,
    COUNT(DISTINCT y.ApplNo) AS TotalApprovals
FROM 
    Product AS x
JOIN 
    RegActionDate AS y ON x.ApplNo = y.ApplNo
WHERE 
    y.ActionType = 'AP'
    AND x.Form IN ('TABLET;ORAL', 'INJECTABLE;INJECTION', 'CAPSULE;ORAL')
GROUP BY 
    ApprovalYear, SuccessfulDosageForm
ORDER BY 
    ApprovalYear, TotalApprovals DESC;
-- OR
SELECT 
    ApprovalYear,
    SuccessfulDosageForm,
    TotalApprovals
FROM (
    SELECT 
        YEAR(y.ActionDate) AS ApprovalYear,
        x.Form AS SuccessfulDosageForm,
        COUNT(DISTINCT y.ApplNo) AS TotalApprovals,
        RANK() OVER (PARTITION BY YEAR(y.ActionDate) ORDER BY COUNT(DISTINCT y.ApplNo) DESC) AS FormRank
    FROM 
        Product AS x
    JOIN 
        RegActionDate AS y ON x.ApplNo = y.ApplNo
    WHERE 
        y.ActionType = 'AP'
    GROUP BY 
        ApprovalYear, SuccessfulDosageForm
) AS YearlyTrends
WHERE 
    FormRank <= 3
ORDER BY 
    ApprovalYear, TotalApprovals DESC;

-- Task 4: Exploring Therapeutic Classes and Approval Trends
-- 1.Analyze drug approvals based on therapeutic evaluation code (TE_Code).
	SELECT 
		TECode,
		COUNT(*) AS TotalApprovals
	FROM 
		Product
	GROUP BY 
		TECode
	ORDER BY 
		TotalApprovals DESC;
    
-- 2.Determine the therapeutic evaluation code (TE_Code) with the highest number of Approvals in each year.
WITH TECodeApprovals AS (
    SELECT 
        YEAR(y.ActionDate) AS ApprovalYear,
        x.TECode,
        COUNT(DISTINCT y.ApplNo) AS TotalApprovals,
        RANK() OVER (PARTITION BY YEAR(y.ActionDate) ORDER BY COUNT(DISTINCT y.ApplNo) DESC) AS ApprovalRank
    FROM 
        Product AS x
    JOIN 
        RegActionDate AS y ON x.ApplNo = y.ApplNo
    WHERE 
        y.ActionType = 'AP'
    GROUP BY 
        ApprovalYear, x.TECode
)
SELECT 
    ApprovalYear,
    TECode,
    TotalApprovals
FROM 
    TECodeApprovals
WHERE 
    ApprovalRank = 1;
